"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
from kover import autoinstall  # noqa: F401

import xbmc
import sys
import json
import re
import time
import threading


xbmc.log('Python Version: {}'.format(sys.version), 1)


if False:
    import xbmcgui
    xbmcgui.Dialog().notification('FanFilm', ('[service.py] has been started'), xbmcgui.NOTIFICATION_INFO, time=500, sound=False)


"""
resolverEnabled = json.loads(xbmc.executeJSONRPC(
    f'{{"jsonrpc":"2.0", "id":1, "method":"Addons.GetAddonDetails", "params":{{"addonid":"{"script.module.resolveurl"}", "properties":["enabled"]}}}}'))[
        "result"]["addon"]["enabled"]
"""

def checkIfPTWisEnabled():
    ptwEnabled = json.loads(xbmc.executeJSONRPC(
        f'{{"jsonrpc":"2.0", "id":1, "method":"Addons.GetAddonDetails", "params":{{"addonid":"{"script.module.ptw"}", "properties":["enabled"]}}}}'))[
            "result"]["addon"]["enabled"]
    #xbmc.log(f"[FanFilm]  [service.py]  {ptwEnabled=}", 1)
    return ptwEnabled


ptwEnabled = checkIfPTWisEnabled()


if not ptwEnabled:
    from checker import ResolveUrlChecker, PtwModuleChecker
    ResolveUrlChecker().setResolveUrl(enabled=True)
    PtwModuleChecker().setPtwModule(enabled=True)
    xbmc.sleep(2000)
    ptwEnabled = checkIfPTWisEnabled()


if ptwEnabled:
    from ptw.libraries import control
    from ptw.libraries import log_utils
    from ptw.libraries import cache

    import xbmcaddon
    control.setting = xbmcaddon.Addon().getSetting
    control.setSetting = xbmcaddon.Addon().setSetting

    # logsilent = xbmcaddon.Addon().getSetting("logsilent") == "true"
    logsilent = control.setting("logsilent") == "true"
    control.log(f'[FanFilm]  [service.py]  {logsilent=}', 1)
    logexceptionsilent = control.setting("logexceptionsilent") == "true"
    control.log(f'[FanFilm]  [service.py]  {logexceptionsilent=}', 1)

    if control.setting("autostart") == "true":
        log_utils.log("Automatic startup is ON", log_utils.LOGINFO, )
        control.infoDialog('Poczekaj na automatyczne uruchomienie', time=1, sound=False)
        plugin_id = xbmcaddon.Addon().getAddonInfo('id')
        # control.execute("ActivateWindow(10025, plugin://plugin.video.fanfilm, return)")
        control.execute(f"ActivateWindow(10025, plugin://{plugin_id}, return)")


    monitor = xbmc.Monitor()


    def cyclic_call(interval, delay, func, *args, **kwargs):
        # xbmc.log(f'[FanFilm]  [service.py]  [cyclic_call]  {interval=}  {func.__name__=}  {args=}  {kwargs=}', 1)
        def calling():
            # monitor = xbmc.Monitor()
            monitor.waitForAbort(delay)  # sleeps for {delay} in secs or returns early if kodi aborts
            # log_utils.log("###############################################################", log_utils.LOGINFO, )
            log_utils.log(f"#################### STARTING {func.__name__} SCHEDULING ################", log_utils.LOGINFO, )
            while True:
                # log_utils.log(f"### NEXT CALL FOR {func.__name__} ON {int(interval/3600)} HOURS ###", log_utils.LOGINFO, )
                monitor.waitForAbort(interval)  # sleeps for {interval} in secs or returns early if kodi aborts
                if monitor.abortRequested():  # abort was requested to Kodi (e.g. shutdown)
                    xbmc.log(f"[FanFilm]  [service.py]  stopping cyclic_call for {func.__name__}, because abort was requested to Kodi", 1)
                    return sys.exit()  # do cleanup logic
                if not sync:
                    func(*args, **kwargs)
                else:
                    # thread = threading.Thread(target=func, args=args, kwargs=kwargs).start()  # już nie muszę tak
                    func(*args, **kwargs)

        thread = threading.Thread(target=calling)
        thread.start()
        # return thread  # po co to?


    def delay_call(delay, interval, func, *args, **kwargs):
        # xbmc.log(f'[FanFilm]  [service.py]  [delay_call]  {delay=}  {func.__name__=}  {args=}  {kwargs=}', 1)
        def calling():
            log_utils.log(f"### {func.__name__} DELAYED BY {int(delay/60)} MINUTES ################", log_utils.LOGINFO, )
            # monitor = xbmc.Monitor()
            monitor.waitForAbort(delay)  # sleeps for {delay} in secs or returns early if kodi aborts
            if monitor.abortRequested():  # abort was requested to Kodi (e.g. shutdown)
                xbmc.log(f"[FanFilm]  [service.py]  stopping delay_call for {func.__name__}, because abort was requested to Kodi", 1)
                return sys.exit()  # do cleanup logic
            if interval:
                # log_utils.log(f"### NEXT CALL ON {int(interval/3600)} HOURS ###", log_utils.LOGINFO, )
                cyclic_call(interval, 0, func, *args, **kwargs)
                pass
            func(*args, **kwargs)

        thread = threading.Thread(target=calling)
        thread.start()
        # return thread  # po co to?


    def moviesAndtvshowsToLibrarySilent(url, movies=True, tvshows=True):
        movies  = int(bool(movies))
        tvshows = int(bool(tvshows))
        log_utils.log(f'[moviesAndtvshowsToLibrarySilent]  {url=}  {movies=}  {tvshows=}', 1)
        control.execute("RunPlugin(plugin://%s)" % f"plugin.video.fanfilm/?action=moviesAndtvshowsToLibrarySilent&url={url}&movies={movies}&tvshows={tvshows}")


    def syncTraktLibrary(movies=True, tvshows=True, sync=False):
        log_utils.log(f'[syncTraktLibrary]  {movies=}  {tvshows=}  {sync=}', 1)
        if not sync:
            if movies:
                control.execute("RunPlugin(plugin://%s)" % "plugin.video.fanfilm/?action=moviesToLibrarySilent&url=traktcollection")
            if tvshows:
                monitor.waitForAbort(1)
                control.execute("RunPlugin(plugin://%s)" % "plugin.video.fanfilm/?action=tvshowsToLibrarySilent&url=traktcollection")
        else:
            moviesAndtvshowsToLibrarySilent("traktcollection", movies, tvshows)
        # log_utils.log("### TRAKT LIBRARY UPDATE - NEXT ON  " + control.setting("schedTraktTime") + " HOURS ################", log_utils.LOGINFO, )


    def syncTMDBLibrary(movies=True, tvshows=True, sync=False):
        log_utils.log(f'[syncTMDBLibrary]  {movies=}  {tvshows=}  {sync=}', 1)
        if not sync:
            if movies:
                control.execute("RunPlugin(plugin://%s)" % "plugin.video.fanfilm/?action=moviesToLibrarySilent&url=tmdbuserfavourite")
            if tvshows:
                monitor.waitForAbort(1)
                control.execute("RunPlugin(plugin://%s)" % "plugin.video.fanfilm/?action=tvshowsToLibrarySilent&url=tmdbuserfavourite")
        else:
            moviesAndtvshowsToLibrarySilent("tmdbuserfavourite", movies, tvshows)
        # monitor.waitForAbort(1)
        # log_utils.log("### TMDB LIBRARY UPDATE - NEXT ON  " + control.setting("schedTmdbTime") + " HOURS ################", log_utils.LOGINFO, )


    def syncIMdbLibrary(movies=True, tvshows=True, sync=False):
        log_utils.log(f'[syncIMdbLibrary]  {movies=}  {tvshows=}  {sync=}', 1)
        if not sync:
            if movies:
                control.execute("RunPlugin(plugin://%s)" % "plugin.video.fanfilm/?action=moviesToLibrarySilent&url=imdbwatchlist")
            if tvshows:
                monitor.waitForAbort(1)
                control.execute("RunPlugin(plugin://%s)" % "plugin.video.fanfilm/?action=tvshowsToLibrarySilent&url=imdbwatchlist")
        else:
            moviesAndtvshowsToLibrarySilent("imdbwatchlist", movies, tvshows)
        # log_utils.log("### IMdb LIBRARY UPDATE - NEXT ON  " + control.setting("schedIMdbTime") + " HOURS ################", log_utils.LOGINFO, )


    def cacheCleanTimer():
        control.execute("RunPlugin(plugin://%s)" % "plugin.video.fanfilm/?action=clearCacheAllSilent")
        # log_utils.log("### CACHE CLEAN - NEXT ON  " + control.setting("schedCleanCache") + " HOURS ################", log_utils.LOGINFO, )


    try:
        MediaVersion = control.addon("script.fanfilm.media").getAddonInfo("version")
        AddonVersion = control.addon("plugin.video.fanfilm").getAddonInfo("version")
        PTWVersion = control.addon("script.module.ptw").getAddonInfo("version")
        control.setSetting("addon.version", AddonVersion)
        control.setSetting("ptw.version", PTWVersion)
        control.log("######################### FANFILM ############################", log_utils.LOGINFO, )
        control.log("####### CURRENT FANFILM VERSIONS REPORT ######################", log_utils.LOGINFO, )
        control.log("### FANFILM PLUGIN VERSION: %s ###" % str(AddonVersion), log_utils.LOGINFO)
        control.log("### FANFILM MEDIA  VERSION: %s ###" % str(MediaVersion), log_utils.LOGINFO)
        control.log("### PTW MODULE     VERSION: %s ###" % str(PTWVersion), log_utils.LOGINFO)
        control.log("###############################################################", log_utils.LOGINFO, )
    except:
        control.log("######################### FANFILM ############################", log_utils.LOGINFO, )
        control.log("####### CURRENT FANFILM VERSIONS REPORT ######################", log_utils.LOGINFO, )
        control.log("### ERROR GETTING FANFILM VERSIONS - NO HELP WILL BE GIVEN AS THIS IS NOT AN OFFICIAL FANFILM INSTALL. ###", log_utils.LOGINFO, )
        control.log("###############################################################", log_utils.LOGINFO, )


    if control.setting("autoCleanCacheAll") == "true":
        cache.cache_clear_all()
        log_utils.log("######################### FANFILM ############################", log_utils.LOGINFO, )
        log_utils.log("######## Wyczyszczono pamięć podręczną #######################", log_utils.LOGINFO, )
        log_utils.log("###############################################################", log_utils.LOGINFO, )


    if int(control.setting("schedCleanCache")) > 0:
        log_utils.log("###############################################################", log_utils.LOGINFO, )
        log_utils.log("#################### STARTING CLEAN SCHEDULING ################", log_utils.LOGINFO, )
        log_utils.log("#################### SCHEDULED TIME FRAME " + control.setting("schedCleanCache") + " HOURS ################", log_utils.LOGINFO, )
        interval = 3600 * int(control.setting("schedCleanCache"))
        cyclic_call(interval, 0, cacheCleanTimer)


    if int(control.setting("schedTraktTime")) > 0:
        movies  = control.setting("contentTraktOnStart") == "0" or control.setting("contentTraktOnStart") == "1"
        tvshows = control.setting("contentTraktOnStart") == "0" or control.setting("contentTraktOnStart") == "2"
        sync = control.setting("syncOrderForTraktOnStart") == "true"
        kwargs = {"movies":movies, "tvshows":tvshows, "sync":sync}
        log_utils.log(f'[FanFilm]  [service.py]  Trakt {kwargs=}', 1)
        monitor.waitForAbort(1)
        log_utils.log("###############################################################", log_utils.LOGINFO, )
        log_utils.log("#################### STARTING Trakt SCHEDULING ################", log_utils.LOGINFO, )
        log_utils.log("#################### SCHEDULED TIME FRAME " + control.setting("schedTraktTime") + " HOURS ################", log_utils.LOGINFO, )
        interval = 3600 * int(control.setting("schedTraktTime"))
        delay = 60 * int(control.setting("autoTraktOnStartDelay")) if control.setting("autoTraktOnStartDelay") != "0" else 0
        cyclic_call(interval, delay, syncTraktLibrary, **kwargs)

    if control.setting("autoTraktOnStart") == "true":
        movies  = control.setting("contentTraktOnStart") == "0" or control.setting("contentTraktOnStart") == "1"
        tvshows = control.setting("contentTraktOnStart") == "0" or control.setting("contentTraktOnStart") == "2"
        sync = control.setting("syncOrderForTraktOnStart") == "true"
        kwargs = {"movies":movies, "tvshows":tvshows, "sync":sync}
        log_utils.log(f'[FanFilm]  [service.py]  Trakt {kwargs=}', 1)
        monitor.waitForAbort(1)
        if control.setting("autoTraktOnStartDelay") != "0":
            log_utils.log("### Trakt LIBRARY UPDATE DELAYED BY " + control.setting("autoTraktOnStartDelay") + " MINUTES ################", log_utils.LOGINFO, )
            delay = 60 * int(control.setting("autoTraktOnStartDelay"))
            delay_call(delay, 0, syncTraktLibrary, **kwargs)
        else:
            log_utils.log("### Trakt LIBRARY UPDATE ###", log_utils.LOGINFO, )
            syncTraktLibrary(**kwargs)


    if int(control.setting("schedTmdbTime")) > 0:
        movies  = control.setting("contentTmdbOnStart") == "0" or control.setting("contentTmdbOnStart") == "1"
        tvshows = control.setting("contentTmdbOnStart") == "0" or control.setting("contentTmdbOnStart") == "2"
        sync = control.setting("syncOrderForTmdbOnStart") == "true"
        kwargs = {"movies":movies, "tvshows":tvshows, "sync":sync}
        log_utils.log(f'[FanFilm]  [service.py]  Tmdb {kwargs=}', 1)
        monitor.waitForAbort(2)
        log_utils.log("###############################################################", log_utils.LOGINFO, )
        log_utils.log("#################### STARTING TMDB SCHEDULING ################", log_utils.LOGINFO, )
        log_utils.log("#################### SCHEDULED TIME FRAME " + control.setting("schedTmdbTime") + " HOURS ################", log_utils.LOGINFO, )
        interval = 3600 * int(control.setting("schedTmdbTime"))
        delay = 60 * int(control.setting("autoTmdbOnStartDelay")) if control.setting("autoTmdbOnStartDelay") != "0" else 0
        cyclic_call(interval, delay, syncTMDBLibrary, **kwargs)

    if control.setting("autoTmdbOnStart") == "true":
        movies  = control.setting("contentTmdbOnStart") == "0" or control.setting("contentTmdbOnStart") == "1"
        tvshows = control.setting("contentTmdbOnStart") == "0" or control.setting("contentTmdbOnStart") == "2"
        sync = control.setting("syncOrderForTmdbOnStart") == "true"
        kwargs = {"movies":movies, "tvshows":tvshows, "sync":sync}
        log_utils.log(f'[FanFilm]  [service.py]  Tmdb {kwargs=}', 1)
        monitor.waitForAbort(2)
        if control.setting("autoTmdbOnStartDelay") != "0":
            log_utils.log("### TMDB LIBRARY UPDATE DELAYED BY " + control.setting("autoTmdbOnStartDelay") + " MINUTES ################", log_utils.LOGINFO, )
            delay = 60 * int(control.setting("autoTmdbOnStartDelay"))
            delay_call(delay, 0, syncTMDBLibrary, **kwargs)
        else:
            log_utils.log("### TMDB LIBRARY UPDATE ###", log_utils.LOGINFO, )
            syncTMDBLibrary(**kwargs)


    if int(control.setting("schedIMdbTime")) > 0:
        movies  = control.setting("contentIMdbOnStart") == "0" or control.setting("contentIMdbOnStart") == "1"
        tvshows = control.setting("contentIMdbOnStart") == "0" or control.setting("contentIMdbOnStart") == "2"
        sync = control.setting("syncOrderForIMdbOnStart") == "true"
        kwargs = {"movies":movies, "tvshows":tvshows, "sync":sync}
        log_utils.log(f'[FanFilm]  [service.py]  IMdb {kwargs=}', 1)
        monitor.waitForAbort(3)
        log_utils.log("###############################################################", log_utils.LOGINFO, )
        log_utils.log("#################### STARTING IMdb SCHEDULING ################", log_utils.LOGINFO, )
        log_utils.log("#################### SCHEDULED TIME FRAME " + control.setting("schedIMdbTime") + " HOURS ################", log_utils.LOGINFO, )
        interval = 3600 * int(control.setting("schedIMdbTime"))
        delay = 60 * int(control.setting("autoIMdbOnStartDelay")) if control.setting("autoIMdbOnStartDelay") != "0" else 0
        cyclic_call(interval, delay, syncIMdbLibrary, **kwargs)

    if control.setting("autoIMdbOnStart") == "true":
        movies  = control.setting("contentIMdbOnStart") == "0" or control.setting("contentIMdbOnStart") == "1"
        tvshows = control.setting("contentIMdbOnStart") == "0" or control.setting("contentIMdbOnStart") == "2"
        sync = control.setting("syncOrderForIMdbOnStart") == "true"
        kwargs = {"movies":movies, "tvshows":tvshows, "sync":sync}
        log_utils.log(f'[FanFilm]  [service.py]  IMdb {kwargs=}', 1)
        monitor.waitForAbort(3)
        if control.setting("autoIMdbOnStartDelay") != "0":
            log_utils.log("### IMDb LIBRARY UPDATE DELAYED BY " + control.setting("autoIMdbOnStartDelay") + " MINUTES ################", log_utils.LOGINFO, )
            delay = 60 * int(control.setting("autoIMdbOnStartDelay"))
            delay_call(delay, 0, syncIMdbLibrary, **kwargs)
        else:
            log_utils.log("### IMDb LIBRARY UPDATE ###", log_utils.LOGINFO, )
            syncIMdbLibrary(**kwargs)


    # clean downloaded database
    try:
        from ptw.libraries import downloader
        downloader.clear_db()
    except:
        pass

    # log_utils.log(f'{sys.argv[0]=}',1)  # tu jest puste

    monitor.waitForAbort(60*1)  # czy da się wstrzelić pomiędzy inne synchronizacje?
    if not monitor.abortRequested():    
        # look in default.py what is going to run
        # control.execute("RunPlugin(plugin://%s)" % control.get_plugin_url({"action": "libepisodesservice"}))  # new thread

        # log_utils.log("starting service (cyclic) for checking and updating library episodes", log_utils.LOGINFO)
        # from ptw.libraries import libtools
        # threading.Thread( target=libtools.libepisodes().service ).start()  # nie testowałem jeszcze

        # current thread - must be at the end of this script
        log_utils.log("[service.py] starting cyclic checking and updating library episodes process", log_utils.LOGINFO)
        from ptw.libraries import libtools
        libtools.libepisodes().service()
        # don't put anything more here (ponieważ linijka powyżej wywołuje funkcję działającą w nieskończoność)
else:
    xbmc.log("[FanFilm]  [service.py]  ERROR: PTW module is not enabled", 1)
    import xbmcgui
    # xbmcgui.Dialog().ok('Error', 'PTW module is not enabled')
    xbmcgui.Dialog().notification('FanFilm', ('PTW module is not enabled'), xbmcgui.NOTIFICATION_ERROR)
    pass